﻿
namespace ES_project2
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            this.Btn_cost = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Btn_supplier = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Btn_receipe = new Bunifu.Framework.UI.BunifuFlatButton();
            this.line1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.Btn_inventry = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Btn_waste_manage = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuImageButton2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuImageButton5 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuCustomLabel35 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lbl_id = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.panelAddProduct = new System.Windows.Forms.Panel();
            this.bunifuCustomLabel17 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.update_pqua = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuCustomLabel12 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.update_pid = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuFlatButton5 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuCustomLabel22 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel19 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.exp_date = new Bunifu.Framework.UI.BunifuDatepicker();
            this.p_price = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuCustomLabel18 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.p_qua = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuCustomLabel15 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel11 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.p_name = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuCustomLabel14 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pid = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuFlatButton11 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panelAddReceipe = new System.Windows.Forms.Panel();
            this.bunifuSeparator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuFlatButton6 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.rece_view = new System.Windows.Forms.DataGridView();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel7 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel9 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel10 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panelAddSupplier = new System.Windows.Forms.Panel();
            this.bunifuCustomLabel20 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.supp_items = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuCustomLabel25 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.supp_phone = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuCustomLabel26 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel28 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.supp_name = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuCustomLabel29 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.supp_id = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuFlatButton2 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panelAddWasteMangement = new System.Windows.Forms.Panel();
            this.bunifuCustomLabel42 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.supp_pay = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuCustomLabel45 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.ele_bill = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuCustomLabel48 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.cook_pay = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuCustomLabel50 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.inv_price = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuFlatButton4 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.r_name = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.r_cost = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.r_note = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.test2 = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuFlatButton7 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton8 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.supp_view = new System.Windows.Forms.DataGridView();
            this.bunifuSeparator3 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuFlatButton9 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton12 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton10 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton13 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.datepick_cost = new Bunifu.Framework.UI.BunifuDatepicker();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.tot = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.panelCostCalculate = new System.Windows.Forms.Panel();
            this.bunifuFlatButton14 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.suppView = new System.Windows.Forms.DataGridView();
            this.bunifuCustomLabel8 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel27 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.invView = new System.Windows.Forms.DataGridView();
            this.bunifuCustomLabel13 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuImageButton4 = new Bunifu.Framework.UI.BunifuImageButton();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton5)).BeginInit();
            this.panelAddProduct.SuspendLayout();
            this.panelAddReceipe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rece_view)).BeginInit();
            this.panelAddSupplier.SuspendLayout();
            this.panelAddWasteMangement.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.supp_view)).BeginInit();
            this.panelCostCalculate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.suppView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton4)).BeginInit();
            this.SuspendLayout();
            // 
            // Btn_cost
            // 
            this.Btn_cost.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Btn_cost.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(62)))), ((int)(((byte)(74)))));
            this.Btn_cost.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_cost.BorderRadius = 0;
            this.Btn_cost.ButtonText = "Check All";
            this.Btn_cost.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_cost.DisabledColor = System.Drawing.Color.Gray;
            this.Btn_cost.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_cost.Iconcolor = System.Drawing.Color.Transparent;
            this.Btn_cost.Iconimage = null;
            this.Btn_cost.Iconimage_right = null;
            this.Btn_cost.Iconimage_right_Selected = null;
            this.Btn_cost.Iconimage_Selected = null;
            this.Btn_cost.IconMarginLeft = 0;
            this.Btn_cost.IconMarginRight = 0;
            this.Btn_cost.IconRightVisible = true;
            this.Btn_cost.IconRightZoom = 0D;
            this.Btn_cost.IconVisible = true;
            this.Btn_cost.IconZoom = 90D;
            this.Btn_cost.IsTab = false;
            this.Btn_cost.Location = new System.Drawing.Point(1123, 108);
            this.Btn_cost.Margin = new System.Windows.Forms.Padding(5);
            this.Btn_cost.Name = "Btn_cost";
            this.Btn_cost.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(62)))), ((int)(((byte)(74)))));
            this.Btn_cost.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.Btn_cost.OnHoverTextColor = System.Drawing.Color.White;
            this.Btn_cost.selected = false;
            this.Btn_cost.Size = new System.Drawing.Size(232, 73);
            this.Btn_cost.TabIndex = 65;
            this.Btn_cost.Text = "Check All";
            this.Btn_cost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Btn_cost.Textcolor = System.Drawing.Color.White;
            this.Btn_cost.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_cost.Click += new System.EventHandler(this.Cost_tab_Click);
            // 
            // Btn_supplier
            // 
            this.Btn_supplier.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Btn_supplier.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(62)))), ((int)(((byte)(74)))));
            this.Btn_supplier.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_supplier.BorderRadius = 0;
            this.Btn_supplier.ButtonText = "Supplier Management";
            this.Btn_supplier.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_supplier.DisabledColor = System.Drawing.Color.Gray;
            this.Btn_supplier.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_supplier.Iconcolor = System.Drawing.Color.Transparent;
            this.Btn_supplier.Iconimage = null;
            this.Btn_supplier.Iconimage_right = null;
            this.Btn_supplier.Iconimage_right_Selected = null;
            this.Btn_supplier.Iconimage_Selected = null;
            this.Btn_supplier.IconMarginLeft = 0;
            this.Btn_supplier.IconMarginRight = 0;
            this.Btn_supplier.IconRightVisible = true;
            this.Btn_supplier.IconRightZoom = 0D;
            this.Btn_supplier.IconVisible = true;
            this.Btn_supplier.IconZoom = 90D;
            this.Btn_supplier.IsTab = false;
            this.Btn_supplier.Location = new System.Drawing.Point(619, 108);
            this.Btn_supplier.Margin = new System.Windows.Forms.Padding(5);
            this.Btn_supplier.Name = "Btn_supplier";
            this.Btn_supplier.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(62)))), ((int)(((byte)(74)))));
            this.Btn_supplier.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.Btn_supplier.OnHoverTextColor = System.Drawing.Color.White;
            this.Btn_supplier.selected = false;
            this.Btn_supplier.Size = new System.Drawing.Size(232, 73);
            this.Btn_supplier.TabIndex = 64;
            this.Btn_supplier.Text = "Supplier Management";
            this.Btn_supplier.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Btn_supplier.Textcolor = System.Drawing.Color.White;
            this.Btn_supplier.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_supplier.Click += new System.EventHandler(this.Supplier_tab_Click);
            // 
            // Btn_receipe
            // 
            this.Btn_receipe.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Btn_receipe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(62)))), ((int)(((byte)(74)))));
            this.Btn_receipe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_receipe.BorderRadius = 0;
            this.Btn_receipe.ButtonText = "Recipe Costing ";
            this.Btn_receipe.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_receipe.DisabledColor = System.Drawing.Color.Gray;
            this.Btn_receipe.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_receipe.Iconcolor = System.Drawing.Color.Transparent;
            this.Btn_receipe.Iconimage = null;
            this.Btn_receipe.Iconimage_right = null;
            this.Btn_receipe.Iconimage_right_Selected = null;
            this.Btn_receipe.Iconimage_Selected = null;
            this.Btn_receipe.IconMarginLeft = 0;
            this.Btn_receipe.IconMarginRight = 0;
            this.Btn_receipe.IconRightVisible = true;
            this.Btn_receipe.IconRightZoom = 0D;
            this.Btn_receipe.IconVisible = true;
            this.Btn_receipe.IconZoom = 90D;
            this.Btn_receipe.IsTab = false;
            this.Btn_receipe.Location = new System.Drawing.Point(364, 108);
            this.Btn_receipe.Margin = new System.Windows.Forms.Padding(5);
            this.Btn_receipe.Name = "Btn_receipe";
            this.Btn_receipe.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(62)))), ((int)(((byte)(74)))));
            this.Btn_receipe.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.Btn_receipe.OnHoverTextColor = System.Drawing.Color.White;
            this.Btn_receipe.selected = false;
            this.Btn_receipe.Size = new System.Drawing.Size(217, 73);
            this.Btn_receipe.TabIndex = 63;
            this.Btn_receipe.Text = "Recipe Costing ";
            this.Btn_receipe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Btn_receipe.Textcolor = System.Drawing.Color.White;
            this.Btn_receipe.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_receipe.Click += new System.EventHandler(this.Receipe_tab_Click);
            // 
            // line1
            // 
            this.line1.BackColor = System.Drawing.Color.Transparent;
            this.line1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.line1.LineThickness = 6;
            this.line1.Location = new System.Drawing.Point(148, 190);
            this.line1.Margin = new System.Windows.Forms.Padding(5);
            this.line1.Name = "line1";
            this.line1.Size = new System.Drawing.Size(192, 15);
            this.line1.TabIndex = 62;
            this.line1.Transparency = 255;
            this.line1.Vertical = false;
            // 
            // Btn_inventry
            // 
            this.Btn_inventry.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Btn_inventry.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(62)))), ((int)(((byte)(74)))));
            this.Btn_inventry.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_inventry.BorderRadius = 0;
            this.Btn_inventry.ButtonText = "Inventory Management";
            this.Btn_inventry.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_inventry.DisabledColor = System.Drawing.Color.Gray;
            this.Btn_inventry.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_inventry.Iconcolor = System.Drawing.Color.Transparent;
            this.Btn_inventry.Iconimage = null;
            this.Btn_inventry.Iconimage_right = null;
            this.Btn_inventry.Iconimage_right_Selected = null;
            this.Btn_inventry.Iconimage_Selected = null;
            this.Btn_inventry.IconMarginLeft = 0;
            this.Btn_inventry.IconMarginRight = 0;
            this.Btn_inventry.IconRightVisible = true;
            this.Btn_inventry.IconRightZoom = 0D;
            this.Btn_inventry.IconVisible = true;
            this.Btn_inventry.IconZoom = 90D;
            this.Btn_inventry.IsTab = false;
            this.Btn_inventry.Location = new System.Drawing.Point(148, 108);
            this.Btn_inventry.Margin = new System.Windows.Forms.Padding(5);
            this.Btn_inventry.Name = "Btn_inventry";
            this.Btn_inventry.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(62)))), ((int)(((byte)(74)))));
            this.Btn_inventry.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.Btn_inventry.OnHoverTextColor = System.Drawing.Color.White;
            this.Btn_inventry.selected = false;
            this.Btn_inventry.Size = new System.Drawing.Size(192, 73);
            this.Btn_inventry.TabIndex = 61;
            this.Btn_inventry.Text = "Inventory Management";
            this.Btn_inventry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Btn_inventry.Textcolor = System.Drawing.Color.White;
            this.Btn_inventry.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_inventry.Click += new System.EventHandler(this.Inventry_tab_Click);
            // 
            // Btn_waste_manage
            // 
            this.Btn_waste_manage.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Btn_waste_manage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(62)))), ((int)(((byte)(74)))));
            this.Btn_waste_manage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_waste_manage.BorderRadius = 0;
            this.Btn_waste_manage.ButtonText = "Cost Management";
            this.Btn_waste_manage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_waste_manage.DisabledColor = System.Drawing.Color.Gray;
            this.Btn_waste_manage.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_waste_manage.Iconcolor = System.Drawing.Color.Transparent;
            this.Btn_waste_manage.Iconimage = null;
            this.Btn_waste_manage.Iconimage_right = null;
            this.Btn_waste_manage.Iconimage_right_Selected = null;
            this.Btn_waste_manage.Iconimage_Selected = null;
            this.Btn_waste_manage.IconMarginLeft = 0;
            this.Btn_waste_manage.IconMarginRight = 0;
            this.Btn_waste_manage.IconRightVisible = true;
            this.Btn_waste_manage.IconRightZoom = 0D;
            this.Btn_waste_manage.IconVisible = true;
            this.Btn_waste_manage.IconZoom = 90D;
            this.Btn_waste_manage.IsTab = false;
            this.Btn_waste_manage.Location = new System.Drawing.Point(888, 108);
            this.Btn_waste_manage.Margin = new System.Windows.Forms.Padding(5);
            this.Btn_waste_manage.Name = "Btn_waste_manage";
            this.Btn_waste_manage.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(62)))), ((int)(((byte)(74)))));
            this.Btn_waste_manage.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.Btn_waste_manage.OnHoverTextColor = System.Drawing.Color.White;
            this.Btn_waste_manage.selected = false;
            this.Btn_waste_manage.Size = new System.Drawing.Size(207, 73);
            this.Btn_waste_manage.TabIndex = 66;
            this.Btn_waste_manage.Text = "Cost Management";
            this.Btn_waste_manage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Btn_waste_manage.Textcolor = System.Drawing.Color.White;
            this.Btn_waste_manage.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_waste_manage.Click += new System.EventHandler(this.Waste_manage_tab_Click);
            // 
            // bunifuImageButton2
            // 
            this.bunifuImageButton2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton2.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton2.Image")));
            this.bunifuImageButton2.ImageActive = null;
            this.bunifuImageButton2.InitialImage = null;
            this.bunifuImageButton2.Location = new System.Drawing.Point(12, 11);
            this.bunifuImageButton2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bunifuImageButton2.Name = "bunifuImageButton2";
            this.bunifuImageButton2.Size = new System.Drawing.Size(128, 94);
            this.bunifuImageButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton2.TabIndex = 59;
            this.bunifuImageButton2.TabStop = false;
            this.bunifuImageButton2.Zoom = 10;
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(295, 27);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(930, 42);
            this.bunifuCustomLabel3.TabIndex = 60;
            this.bunifuCustomLabel3.Text = "FOOD COST MANAGEMENT ADMIN DASHBOARD";
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(1355, 27);
            this.bunifuImageButton1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(37, 38);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton1.TabIndex = 67;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
            this.bunifuImageButton1.Click += new System.EventHandler(this.bunifuImageButton1_Click);
            // 
            // bunifuImageButton5
            // 
            this.bunifuImageButton5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton5.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton5.Image")));
            this.bunifuImageButton5.ImageActive = null;
            this.bunifuImageButton5.InitialImage = null;
            this.bunifuImageButton5.Location = new System.Drawing.Point(31, 618);
            this.bunifuImageButton5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bunifuImageButton5.Name = "bunifuImageButton5";
            this.bunifuImageButton5.Size = new System.Drawing.Size(69, 62);
            this.bunifuImageButton5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton5.TabIndex = 70;
            this.bunifuImageButton5.TabStop = false;
            this.bunifuImageButton5.Zoom = 10;
            this.bunifuImageButton5.Click += new System.EventHandler(this.bunifuImageButton5_Click);
            // 
            // bunifuCustomLabel35
            // 
            this.bunifuCustomLabel35.AutoSize = true;
            this.bunifuCustomLabel35.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel35.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuCustomLabel35.Location = new System.Drawing.Point(-3, 150);
            this.bunifuCustomLabel35.Name = "bunifuCustomLabel35";
            this.bunifuCustomLabel35.Size = new System.Drawing.Size(126, 28);
            this.bunifuCustomLabel35.TabIndex = 68;
            this.bunifuCustomLabel35.Text = "User Name :\r\n";
            // 
            // lbl_id
            // 
            this.lbl_id.AutoSize = true;
            this.lbl_id.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_id.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl_id.Location = new System.Drawing.Point(6, 190);
            this.lbl_id.Name = "lbl_id";
            this.lbl_id.Size = new System.Drawing.Size(38, 35);
            this.lbl_id.TabIndex = 69;
            this.lbl_id.Text = "...";
            // 
            // panelAddProduct
            // 
            this.panelAddProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(65)))), ((int)(((byte)(94)))));
            this.panelAddProduct.Controls.Add(this.bunifuCustomLabel17);
            this.panelAddProduct.Controls.Add(this.update_pqua);
            this.panelAddProduct.Controls.Add(this.bunifuCustomLabel12);
            this.panelAddProduct.Controls.Add(this.update_pid);
            this.panelAddProduct.Controls.Add(this.bunifuFlatButton5);
            this.panelAddProduct.Controls.Add(this.bunifuSeparator1);
            this.panelAddProduct.Controls.Add(this.bunifuCustomLabel22);
            this.panelAddProduct.Controls.Add(this.bunifuCustomLabel19);
            this.panelAddProduct.Controls.Add(this.exp_date);
            this.panelAddProduct.Controls.Add(this.p_price);
            this.panelAddProduct.Controls.Add(this.bunifuCustomLabel18);
            this.panelAddProduct.Controls.Add(this.p_qua);
            this.panelAddProduct.Controls.Add(this.bunifuCustomLabel15);
            this.panelAddProduct.Controls.Add(this.bunifuCustomLabel11);
            this.panelAddProduct.Controls.Add(this.p_name);
            this.panelAddProduct.Controls.Add(this.bunifuCustomLabel14);
            this.panelAddProduct.Controls.Add(this.pid);
            this.panelAddProduct.Controls.Add(this.bunifuFlatButton11);
            this.panelAddProduct.Location = new System.Drawing.Point(148, 224);
            this.panelAddProduct.Margin = new System.Windows.Forms.Padding(4);
            this.panelAddProduct.Name = "panelAddProduct";
            this.panelAddProduct.Size = new System.Drawing.Size(1207, 508);
            this.panelAddProduct.TabIndex = 71;
            // 
            // bunifuCustomLabel17
            // 
            this.bunifuCustomLabel17.AutoSize = true;
            this.bunifuCustomLabel17.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel17.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel17.Location = new System.Drawing.Point(710, 221);
            this.bunifuCustomLabel17.Name = "bunifuCustomLabel17";
            this.bunifuCustomLabel17.Size = new System.Drawing.Size(92, 24);
            this.bunifuCustomLabel17.TabIndex = 88;
            this.bunifuCustomLabel17.Text = "Quantity :\r\n";
            // 
            // update_pqua
            // 
            this.update_pqua.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(120)))), ((int)(((byte)(33)))));
            this.update_pqua.BorderColorIdle = System.Drawing.Color.Silver;
            this.update_pqua.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(252)))), ((int)(((byte)(69)))));
            this.update_pqua.BorderThickness = 3;
            this.update_pqua.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.update_pqua.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.update_pqua.ForeColor = System.Drawing.Color.White;
            this.update_pqua.isPassword = false;
            this.update_pqua.Location = new System.Drawing.Point(714, 248);
            this.update_pqua.Margin = new System.Windows.Forms.Padding(5);
            this.update_pqua.Name = "update_pqua";
            this.update_pqua.Size = new System.Drawing.Size(405, 46);
            this.update_pqua.TabIndex = 86;
            this.update_pqua.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel12
            // 
            this.bunifuCustomLabel12.AutoSize = true;
            this.bunifuCustomLabel12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel12.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel12.Location = new System.Drawing.Point(710, 137);
            this.bunifuCustomLabel12.Name = "bunifuCustomLabel12";
            this.bunifuCustomLabel12.Size = new System.Drawing.Size(107, 24);
            this.bunifuCustomLabel12.TabIndex = 85;
            this.bunifuCustomLabel12.Text = "Product ID :\r\n";
            // 
            // update_pid
            // 
            this.update_pid.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(120)))), ((int)(((byte)(33)))));
            this.update_pid.BorderColorIdle = System.Drawing.Color.Silver;
            this.update_pid.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(252)))), ((int)(((byte)(69)))));
            this.update_pid.BorderThickness = 3;
            this.update_pid.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.update_pid.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.update_pid.ForeColor = System.Drawing.Color.White;
            this.update_pid.isPassword = false;
            this.update_pid.Location = new System.Drawing.Point(714, 164);
            this.update_pid.Margin = new System.Windows.Forms.Padding(5);
            this.update_pid.Name = "update_pid";
            this.update_pid.Size = new System.Drawing.Size(405, 46);
            this.update_pid.TabIndex = 84;
            this.update_pid.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuFlatButton5
            // 
            this.bunifuFlatButton5.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton5.BorderRadius = 0;
            this.bunifuFlatButton5.ButtonText = "Update Product";
            this.bunifuFlatButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton5.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton5.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton5.Iconimage = null;
            this.bunifuFlatButton5.Iconimage_right = null;
            this.bunifuFlatButton5.Iconimage_right_Selected = null;
            this.bunifuFlatButton5.Iconimage_Selected = null;
            this.bunifuFlatButton5.IconMarginLeft = 0;
            this.bunifuFlatButton5.IconMarginRight = 0;
            this.bunifuFlatButton5.IconRightVisible = true;
            this.bunifuFlatButton5.IconRightZoom = 0D;
            this.bunifuFlatButton5.IconVisible = true;
            this.bunifuFlatButton5.IconZoom = 90D;
            this.bunifuFlatButton5.IsTab = false;
            this.bunifuFlatButton5.Location = new System.Drawing.Point(931, 420);
            this.bunifuFlatButton5.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuFlatButton5.Name = "bunifuFlatButton5";
            this.bunifuFlatButton5.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton5.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton5.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton5.selected = false;
            this.bunifuFlatButton5.Size = new System.Drawing.Size(247, 46);
            this.bunifuFlatButton5.TabIndex = 83;
            this.bunifuFlatButton5.Text = "Update Product";
            this.bunifuFlatButton5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton5.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton5.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton5.Click += new System.EventHandler(this.bunifuFlatButton5_Click);
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuSeparator1.LineThickness = 3;
            this.bunifuSeparator1.Location = new System.Drawing.Point(605, 80);
            this.bunifuSeparator1.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(17, 386);
            this.bunifuSeparator1.TabIndex = 82;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = true;
            // 
            // bunifuCustomLabel22
            // 
            this.bunifuCustomLabel22.AutoSize = true;
            this.bunifuCustomLabel22.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel22.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuCustomLabel22.Location = new System.Drawing.Point(469, 14);
            this.bunifuCustomLabel22.Name = "bunifuCustomLabel22";
            this.bunifuCustomLabel22.Size = new System.Drawing.Size(295, 32);
            this.bunifuCustomLabel22.TabIndex = 47;
            this.bunifuCustomLabel22.Text = "MANAGE PRODUCT";
            // 
            // bunifuCustomLabel19
            // 
            this.bunifuCustomLabel19.AutoSize = true;
            this.bunifuCustomLabel19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel19.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel19.Location = new System.Drawing.Point(101, 388);
            this.bunifuCustomLabel19.Name = "bunifuCustomLabel19";
            this.bunifuCustomLabel19.Size = new System.Drawing.Size(149, 24);
            this.bunifuCustomLabel19.TabIndex = 46;
            this.bunifuCustomLabel19.Text = "Expiration Date :\r\n";
            // 
            // exp_date
            // 
            this.exp_date.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(222)))));
            this.exp_date.BorderRadius = 0;
            this.exp_date.ForeColor = System.Drawing.Color.White;
            this.exp_date.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.exp_date.FormatCustom = null;
            this.exp_date.Location = new System.Drawing.Point(105, 420);
            this.exp_date.Margin = new System.Windows.Forms.Padding(5);
            this.exp_date.Name = "exp_date";
            this.exp_date.Size = new System.Drawing.Size(405, 46);
            this.exp_date.TabIndex = 44;
            this.exp_date.Value = new System.DateTime(2022, 11, 9, 14, 47, 18, 904);
            // 
            // p_price
            // 
            this.p_price.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(120)))), ((int)(((byte)(33)))));
            this.p_price.BorderColorIdle = System.Drawing.Color.Silver;
            this.p_price.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(252)))), ((int)(((byte)(69)))));
            this.p_price.BorderThickness = 3;
            this.p_price.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.p_price.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_price.ForeColor = System.Drawing.Color.White;
            this.p_price.isPassword = false;
            this.p_price.Location = new System.Drawing.Point(105, 248);
            this.p_price.Margin = new System.Windows.Forms.Padding(5);
            this.p_price.Name = "p_price";
            this.p_price.Size = new System.Drawing.Size(405, 46);
            this.p_price.TabIndex = 43;
            this.p_price.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel18
            // 
            this.bunifuCustomLabel18.AutoSize = true;
            this.bunifuCustomLabel18.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel18.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel18.Location = new System.Drawing.Point(104, 221);
            this.bunifuCustomLabel18.Name = "bunifuCustomLabel18";
            this.bunifuCustomLabel18.Size = new System.Drawing.Size(60, 24);
            this.bunifuCustomLabel18.TabIndex = 41;
            this.bunifuCustomLabel18.Text = "Price :\r\n";
            // 
            // p_qua
            // 
            this.p_qua.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(120)))), ((int)(((byte)(33)))));
            this.p_qua.BorderColorIdle = System.Drawing.Color.Silver;
            this.p_qua.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(252)))), ((int)(((byte)(69)))));
            this.p_qua.BorderThickness = 3;
            this.p_qua.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.p_qua.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_qua.ForeColor = System.Drawing.Color.White;
            this.p_qua.isPassword = false;
            this.p_qua.Location = new System.Drawing.Point(105, 326);
            this.p_qua.Margin = new System.Windows.Forms.Padding(5);
            this.p_qua.Name = "p_qua";
            this.p_qua.Size = new System.Drawing.Size(405, 46);
            this.p_qua.TabIndex = 38;
            this.p_qua.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel15
            // 
            this.bunifuCustomLabel15.AutoSize = true;
            this.bunifuCustomLabel15.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel15.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel15.Location = new System.Drawing.Point(101, 299);
            this.bunifuCustomLabel15.Name = "bunifuCustomLabel15";
            this.bunifuCustomLabel15.Size = new System.Drawing.Size(92, 24);
            this.bunifuCustomLabel15.TabIndex = 37;
            this.bunifuCustomLabel15.Text = "Quantity :\r\n";
            // 
            // bunifuCustomLabel11
            // 
            this.bunifuCustomLabel11.AutoSize = true;
            this.bunifuCustomLabel11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel11.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel11.Location = new System.Drawing.Point(104, 136);
            this.bunifuCustomLabel11.Name = "bunifuCustomLabel11";
            this.bunifuCustomLabel11.Size = new System.Drawing.Size(139, 24);
            this.bunifuCustomLabel11.TabIndex = 34;
            this.bunifuCustomLabel11.Text = "Product Name :\r\n";
            // 
            // p_name
            // 
            this.p_name.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(120)))), ((int)(((byte)(33)))));
            this.p_name.BorderColorIdle = System.Drawing.Color.Silver;
            this.p_name.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(252)))), ((int)(((byte)(69)))));
            this.p_name.BorderThickness = 3;
            this.p_name.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.p_name.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_name.ForeColor = System.Drawing.Color.White;
            this.p_name.isPassword = false;
            this.p_name.Location = new System.Drawing.Point(105, 164);
            this.p_name.Margin = new System.Windows.Forms.Padding(5);
            this.p_name.Name = "p_name";
            this.p_name.Size = new System.Drawing.Size(405, 46);
            this.p_name.TabIndex = 33;
            this.p_name.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel14
            // 
            this.bunifuCustomLabel14.AutoSize = true;
            this.bunifuCustomLabel14.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel14.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel14.Location = new System.Drawing.Point(101, 53);
            this.bunifuCustomLabel14.Name = "bunifuCustomLabel14";
            this.bunifuCustomLabel14.Size = new System.Drawing.Size(107, 24);
            this.bunifuCustomLabel14.TabIndex = 32;
            this.bunifuCustomLabel14.Text = "Product ID :\r\n";
            // 
            // pid
            // 
            this.pid.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(120)))), ((int)(((byte)(33)))));
            this.pid.BorderColorIdle = System.Drawing.Color.Silver;
            this.pid.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(252)))), ((int)(((byte)(69)))));
            this.pid.BorderThickness = 3;
            this.pid.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.pid.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pid.ForeColor = System.Drawing.Color.White;
            this.pid.isPassword = false;
            this.pid.Location = new System.Drawing.Point(105, 80);
            this.pid.Margin = new System.Windows.Forms.Padding(5);
            this.pid.Name = "pid";
            this.pid.Size = new System.Drawing.Size(405, 46);
            this.pid.TabIndex = 31;
            this.pid.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuFlatButton11
            // 
            this.bunifuFlatButton11.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton11.BorderRadius = 0;
            this.bunifuFlatButton11.ButtonText = "Add Product";
            this.bunifuFlatButton11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton11.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton11.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton11.Iconimage = null;
            this.bunifuFlatButton11.Iconimage_right = null;
            this.bunifuFlatButton11.Iconimage_right_Selected = null;
            this.bunifuFlatButton11.Iconimage_Selected = null;
            this.bunifuFlatButton11.IconMarginLeft = 0;
            this.bunifuFlatButton11.IconMarginRight = 0;
            this.bunifuFlatButton11.IconRightVisible = true;
            this.bunifuFlatButton11.IconRightZoom = 0D;
            this.bunifuFlatButton11.IconVisible = true;
            this.bunifuFlatButton11.IconZoom = 90D;
            this.bunifuFlatButton11.IsTab = false;
            this.bunifuFlatButton11.Location = new System.Drawing.Point(641, 420);
            this.bunifuFlatButton11.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuFlatButton11.Name = "bunifuFlatButton11";
            this.bunifuFlatButton11.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton11.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton11.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton11.selected = false;
            this.bunifuFlatButton11.Size = new System.Drawing.Size(247, 46);
            this.bunifuFlatButton11.TabIndex = 30;
            this.bunifuFlatButton11.Text = "Add Product";
            this.bunifuFlatButton11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton11.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton11.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton11.Click += new System.EventHandler(this.bunifuFlatButton11_Click);
            // 
            // panelAddReceipe
            // 
            this.panelAddReceipe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(65)))), ((int)(((byte)(94)))));
            this.panelAddReceipe.Controls.Add(this.bunifuFlatButton8);
            this.panelAddReceipe.Controls.Add(this.bunifuFlatButton7);
            this.panelAddReceipe.Controls.Add(this.r_note);
            this.panelAddReceipe.Controls.Add(this.r_cost);
            this.panelAddReceipe.Controls.Add(this.r_name);
            this.panelAddReceipe.Controls.Add(this.test2);
            this.panelAddReceipe.Controls.Add(this.bunifuSeparator2);
            this.panelAddReceipe.Controls.Add(this.bunifuFlatButton6);
            this.panelAddReceipe.Controls.Add(this.rece_view);
            this.panelAddReceipe.Controls.Add(this.bunifuCustomLabel2);
            this.panelAddReceipe.Controls.Add(this.bunifuCustomLabel6);
            this.panelAddReceipe.Controls.Add(this.bunifuCustomLabel7);
            this.panelAddReceipe.Controls.Add(this.bunifuCustomLabel9);
            this.panelAddReceipe.Controls.Add(this.bunifuCustomLabel10);
            this.panelAddReceipe.Controls.Add(this.bunifuFlatButton1);
            this.panelAddReceipe.Location = new System.Drawing.Point(148, 224);
            this.panelAddReceipe.Margin = new System.Windows.Forms.Padding(4);
            this.panelAddReceipe.Name = "panelAddReceipe";
            this.panelAddReceipe.Size = new System.Drawing.Size(1207, 508);
            this.panelAddReceipe.TabIndex = 48;
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuSeparator2.LineThickness = 3;
            this.bunifuSeparator2.Location = new System.Drawing.Point(578, 70);
            this.bunifuSeparator2.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(17, 321);
            this.bunifuSeparator2.TabIndex = 83;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = true;
            // 
            // bunifuFlatButton6
            // 
            this.bunifuFlatButton6.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton6.BorderRadius = 0;
            this.bunifuFlatButton6.ButtonText = "Show All Receipes";
            this.bunifuFlatButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton6.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton6.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton6.Iconimage = null;
            this.bunifuFlatButton6.Iconimage_right = null;
            this.bunifuFlatButton6.Iconimage_right_Selected = null;
            this.bunifuFlatButton6.Iconimage_Selected = null;
            this.bunifuFlatButton6.IconMarginLeft = 0;
            this.bunifuFlatButton6.IconMarginRight = 0;
            this.bunifuFlatButton6.IconRightVisible = true;
            this.bunifuFlatButton6.IconRightZoom = 0D;
            this.bunifuFlatButton6.IconVisible = true;
            this.bunifuFlatButton6.IconZoom = 90D;
            this.bunifuFlatButton6.IsTab = false;
            this.bunifuFlatButton6.Location = new System.Drawing.Point(948, 439);
            this.bunifuFlatButton6.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuFlatButton6.Name = "bunifuFlatButton6";
            this.bunifuFlatButton6.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton6.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton6.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton6.selected = false;
            this.bunifuFlatButton6.Size = new System.Drawing.Size(230, 46);
            this.bunifuFlatButton6.TabIndex = 80;
            this.bunifuFlatButton6.Text = "Show All Receipes";
            this.bunifuFlatButton6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton6.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton6.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton6.Click += new System.EventHandler(this.bunifuFlatButton6_Click);
            // 
            // rece_view
            // 
            this.rece_view.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rece_view.Location = new System.Drawing.Point(658, 70);
            this.rece_view.Name = "rece_view";
            this.rece_view.RowHeadersWidth = 51;
            this.rece_view.RowTemplate.Height = 24;
            this.rece_view.Size = new System.Drawing.Size(520, 321);
            this.rece_view.TabIndex = 79;
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(512, 14);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(179, 32);
            this.bunifuCustomLabel2.TabIndex = 78;
            this.bunifuCustomLabel2.Text = "ADD Recipe";
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.AutoSize = true;
            this.bunifuCustomLabel6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel6.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(100, 317);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(69, 24);
            this.bunifuCustomLabel6.TabIndex = 72;
            this.bunifuCustomLabel6.Text = "Notes :\r\n";
            // 
            // bunifuCustomLabel7
            // 
            this.bunifuCustomLabel7.AutoSize = true;
            this.bunifuCustomLabel7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel7.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel7.Location = new System.Drawing.Point(100, 221);
            this.bunifuCustomLabel7.Name = "bunifuCustomLabel7";
            this.bunifuCustomLabel7.Size = new System.Drawing.Size(127, 24);
            this.bunifuCustomLabel7.TabIndex = 70;
            this.bunifuCustomLabel7.Text = "Receipe Cost :\r\n";
            // 
            // bunifuCustomLabel9
            // 
            this.bunifuCustomLabel9.AutoSize = true;
            this.bunifuCustomLabel9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel9.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel9.Location = new System.Drawing.Point(101, 132);
            this.bunifuCustomLabel9.Name = "bunifuCustomLabel9";
            this.bunifuCustomLabel9.Size = new System.Drawing.Size(129, 24);
            this.bunifuCustomLabel9.TabIndex = 67;
            this.bunifuCustomLabel9.Text = "Recipe Name :\r\n";
            // 
            // bunifuCustomLabel10
            // 
            this.bunifuCustomLabel10.AutoSize = true;
            this.bunifuCustomLabel10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel10.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel10.Location = new System.Drawing.Point(99, 43);
            this.bunifuCustomLabel10.Name = "bunifuCustomLabel10";
            this.bunifuCustomLabel10.Size = new System.Drawing.Size(97, 24);
            this.bunifuCustomLabel10.TabIndex = 65;
            this.bunifuCustomLabel10.Text = "Recipe ID :\r\n";
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "Add Receipe";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = null;
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 90D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(658, 439);
            this.bunifuFlatButton1.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(230, 46);
            this.bunifuFlatButton1.TabIndex = 63;
            this.bunifuFlatButton1.Text = "Add Receipe";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton1.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // panelAddSupplier
            // 
            this.panelAddSupplier.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(65)))), ((int)(((byte)(94)))));
            this.panelAddSupplier.Controls.Add(this.bunifuFlatButton12);
            this.panelAddSupplier.Controls.Add(this.bunifuFlatButton10);
            this.panelAddSupplier.Controls.Add(this.bunifuFlatButton9);
            this.panelAddSupplier.Controls.Add(this.bunifuSeparator3);
            this.panelAddSupplier.Controls.Add(this.supp_view);
            this.panelAddSupplier.Controls.Add(this.bunifuCustomLabel20);
            this.panelAddSupplier.Controls.Add(this.supp_items);
            this.panelAddSupplier.Controls.Add(this.bunifuCustomLabel25);
            this.panelAddSupplier.Controls.Add(this.supp_phone);
            this.panelAddSupplier.Controls.Add(this.bunifuCustomLabel26);
            this.panelAddSupplier.Controls.Add(this.bunifuCustomLabel28);
            this.panelAddSupplier.Controls.Add(this.supp_name);
            this.panelAddSupplier.Controls.Add(this.bunifuCustomLabel29);
            this.panelAddSupplier.Controls.Add(this.supp_id);
            this.panelAddSupplier.Controls.Add(this.bunifuFlatButton2);
            this.panelAddSupplier.Location = new System.Drawing.Point(148, 224);
            this.panelAddSupplier.Margin = new System.Windows.Forms.Padding(4);
            this.panelAddSupplier.Name = "panelAddSupplier";
            this.panelAddSupplier.Size = new System.Drawing.Size(1207, 508);
            this.panelAddSupplier.TabIndex = 79;
            // 
            // bunifuCustomLabel20
            // 
            this.bunifuCustomLabel20.AutoSize = true;
            this.bunifuCustomLabel20.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel20.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuCustomLabel20.Location = new System.Drawing.Point(533, 14);
            this.bunifuCustomLabel20.Name = "bunifuCustomLabel20";
            this.bunifuCustomLabel20.Size = new System.Drawing.Size(136, 32);
            this.bunifuCustomLabel20.TabIndex = 44;
            this.bunifuCustomLabel20.Text = "Supplier ";
            // 
            // supp_items
            // 
            this.supp_items.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(120)))), ((int)(((byte)(33)))));
            this.supp_items.BorderColorIdle = System.Drawing.Color.Silver;
            this.supp_items.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(252)))), ((int)(((byte)(69)))));
            this.supp_items.BorderThickness = 3;
            this.supp_items.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.supp_items.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.supp_items.ForeColor = System.Drawing.Color.White;
            this.supp_items.isPassword = false;
            this.supp_items.Location = new System.Drawing.Point(143, 326);
            this.supp_items.Margin = new System.Windows.Forms.Padding(5);
            this.supp_items.Name = "supp_items";
            this.supp_items.Size = new System.Drawing.Size(405, 46);
            this.supp_items.TabIndex = 42;
            this.supp_items.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel25
            // 
            this.bunifuCustomLabel25.AutoSize = true;
            this.bunifuCustomLabel25.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel25.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel25.Location = new System.Drawing.Point(139, 298);
            this.bunifuCustomLabel25.Name = "bunifuCustomLabel25";
            this.bunifuCustomLabel25.Size = new System.Drawing.Size(152, 24);
            this.bunifuCustomLabel25.TabIndex = 40;
            this.bunifuCustomLabel25.Text = "Supplying items :\r\n";
            // 
            // supp_phone
            // 
            this.supp_phone.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(120)))), ((int)(((byte)(33)))));
            this.supp_phone.BorderColorIdle = System.Drawing.Color.Silver;
            this.supp_phone.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(252)))), ((int)(((byte)(69)))));
            this.supp_phone.BorderThickness = 3;
            this.supp_phone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.supp_phone.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.supp_phone.ForeColor = System.Drawing.Color.White;
            this.supp_phone.isPassword = false;
            this.supp_phone.Location = new System.Drawing.Point(142, 251);
            this.supp_phone.Margin = new System.Windows.Forms.Padding(5);
            this.supp_phone.Name = "supp_phone";
            this.supp_phone.Size = new System.Drawing.Size(405, 46);
            this.supp_phone.TabIndex = 39;
            this.supp_phone.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel26
            // 
            this.bunifuCustomLabel26.AutoSize = true;
            this.bunifuCustomLabel26.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel26.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel26.Location = new System.Drawing.Point(138, 224);
            this.bunifuCustomLabel26.Name = "bunifuCustomLabel26";
            this.bunifuCustomLabel26.Size = new System.Drawing.Size(147, 24);
            this.bunifuCustomLabel26.TabIndex = 38;
            this.bunifuCustomLabel26.Text = "Supplier Phone :\r\n";
            // 
            // bunifuCustomLabel28
            // 
            this.bunifuCustomLabel28.AutoSize = true;
            this.bunifuCustomLabel28.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel28.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel28.Location = new System.Drawing.Point(139, 139);
            this.bunifuCustomLabel28.Name = "bunifuCustomLabel28";
            this.bunifuCustomLabel28.Size = new System.Drawing.Size(143, 24);
            this.bunifuCustomLabel28.TabIndex = 35;
            this.bunifuCustomLabel28.Text = "Supplier Name :\r\n";
            // 
            // supp_name
            // 
            this.supp_name.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(120)))), ((int)(((byte)(33)))));
            this.supp_name.BorderColorIdle = System.Drawing.Color.Silver;
            this.supp_name.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(252)))), ((int)(((byte)(69)))));
            this.supp_name.BorderThickness = 3;
            this.supp_name.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.supp_name.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.supp_name.ForeColor = System.Drawing.Color.White;
            this.supp_name.isPassword = false;
            this.supp_name.Location = new System.Drawing.Point(140, 167);
            this.supp_name.Margin = new System.Windows.Forms.Padding(5);
            this.supp_name.Name = "supp_name";
            this.supp_name.Size = new System.Drawing.Size(405, 46);
            this.supp_name.TabIndex = 34;
            this.supp_name.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel29
            // 
            this.bunifuCustomLabel29.AutoSize = true;
            this.bunifuCustomLabel29.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel29.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel29.Location = new System.Drawing.Point(135, 65);
            this.bunifuCustomLabel29.Name = "bunifuCustomLabel29";
            this.bunifuCustomLabel29.Size = new System.Drawing.Size(111, 24);
            this.bunifuCustomLabel29.TabIndex = 33;
            this.bunifuCustomLabel29.Text = "Supplier ID :\r\n";
            // 
            // supp_id
            // 
            this.supp_id.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(120)))), ((int)(((byte)(33)))));
            this.supp_id.BorderColorIdle = System.Drawing.Color.Silver;
            this.supp_id.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(252)))), ((int)(((byte)(69)))));
            this.supp_id.BorderThickness = 3;
            this.supp_id.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.supp_id.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.supp_id.ForeColor = System.Drawing.Color.White;
            this.supp_id.isPassword = false;
            this.supp_id.Location = new System.Drawing.Point(139, 92);
            this.supp_id.Margin = new System.Windows.Forms.Padding(5);
            this.supp_id.Name = "supp_id";
            this.supp_id.Size = new System.Drawing.Size(405, 46);
            this.supp_id.TabIndex = 32;
            this.supp_id.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuFlatButton2
            // 
            this.bunifuFlatButton2.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton2.BorderRadius = 0;
            this.bunifuFlatButton2.ButtonText = "Add Supplier";
            this.bunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.Iconimage = null;
            this.bunifuFlatButton2.Iconimage_right = null;
            this.bunifuFlatButton2.Iconimage_right_Selected = null;
            this.bunifuFlatButton2.Iconimage_Selected = null;
            this.bunifuFlatButton2.IconMarginLeft = 0;
            this.bunifuFlatButton2.IconMarginRight = 0;
            this.bunifuFlatButton2.IconRightVisible = true;
            this.bunifuFlatButton2.IconRightZoom = 0D;
            this.bunifuFlatButton2.IconVisible = true;
            this.bunifuFlatButton2.IconZoom = 90D;
            this.bunifuFlatButton2.IsTab = false;
            this.bunifuFlatButton2.Location = new System.Drawing.Point(931, 420);
            this.bunifuFlatButton2.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuFlatButton2.Name = "bunifuFlatButton2";
            this.bunifuFlatButton2.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton2.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton2.selected = false;
            this.bunifuFlatButton2.Size = new System.Drawing.Size(230, 46);
            this.bunifuFlatButton2.TabIndex = 31;
            this.bunifuFlatButton2.Text = "Add Supplier";
            this.bunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton2.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton2.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton2.Click += new System.EventHandler(this.bunifuFlatButton2_Click);
            // 
            // panelAddWasteMangement
            // 
            this.panelAddWasteMangement.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(65)))), ((int)(((byte)(94)))));
            this.panelAddWasteMangement.Controls.Add(this.tot);
            this.panelAddWasteMangement.Controls.Add(this.bunifuCustomLabel5);
            this.panelAddWasteMangement.Controls.Add(this.bunifuCustomLabel4);
            this.panelAddWasteMangement.Controls.Add(this.datepick_cost);
            this.panelAddWasteMangement.Controls.Add(this.bunifuFlatButton13);
            this.panelAddWasteMangement.Controls.Add(this.bunifuCustomLabel42);
            this.panelAddWasteMangement.Controls.Add(this.supp_pay);
            this.panelAddWasteMangement.Controls.Add(this.bunifuCustomLabel45);
            this.panelAddWasteMangement.Controls.Add(this.ele_bill);
            this.panelAddWasteMangement.Controls.Add(this.bunifuCustomLabel48);
            this.panelAddWasteMangement.Controls.Add(this.cook_pay);
            this.panelAddWasteMangement.Controls.Add(this.bunifuCustomLabel50);
            this.panelAddWasteMangement.Controls.Add(this.inv_price);
            this.panelAddWasteMangement.Controls.Add(this.bunifuFlatButton4);
            this.panelAddWasteMangement.Controls.Add(this.bunifuCustomLabel1);
            this.panelAddWasteMangement.Location = new System.Drawing.Point(148, 224);
            this.panelAddWasteMangement.Margin = new System.Windows.Forms.Padding(4);
            this.panelAddWasteMangement.Name = "panelAddWasteMangement";
            this.panelAddWasteMangement.Size = new System.Drawing.Size(1207, 508);
            this.panelAddWasteMangement.TabIndex = 81;
            // 
            // bunifuCustomLabel42
            // 
            this.bunifuCustomLabel42.AutoSize = true;
            this.bunifuCustomLabel42.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel42.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel42.Location = new System.Drawing.Point(657, 167);
            this.bunifuCustomLabel42.Name = "bunifuCustomLabel42";
            this.bunifuCustomLabel42.Size = new System.Drawing.Size(159, 24);
            this.bunifuCustomLabel42.TabIndex = 98;
            this.bunifuCustomLabel42.Text = "For Electricity Bill:";
            // 
            // supp_pay
            // 
            this.supp_pay.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(120)))), ((int)(((byte)(33)))));
            this.supp_pay.BorderColorIdle = System.Drawing.Color.Silver;
            this.supp_pay.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(252)))), ((int)(((byte)(69)))));
            this.supp_pay.BorderThickness = 3;
            this.supp_pay.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.supp_pay.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.supp_pay.ForeColor = System.Drawing.Color.White;
            this.supp_pay.isPassword = false;
            this.supp_pay.Location = new System.Drawing.Point(657, 110);
            this.supp_pay.Margin = new System.Windows.Forms.Padding(5);
            this.supp_pay.Name = "supp_pay";
            this.supp_pay.Size = new System.Drawing.Size(405, 46);
            this.supp_pay.TabIndex = 93;
            this.supp_pay.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel45
            // 
            this.bunifuCustomLabel45.AutoSize = true;
            this.bunifuCustomLabel45.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel45.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel45.Location = new System.Drawing.Point(653, 75);
            this.bunifuCustomLabel45.Name = "bunifuCustomLabel45";
            this.bunifuCustomLabel45.Size = new System.Drawing.Size(162, 24);
            this.bunifuCustomLabel45.TabIndex = 92;
            this.bunifuCustomLabel45.Text = "Supplier Payment:";
            // 
            // ele_bill
            // 
            this.ele_bill.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(120)))), ((int)(((byte)(33)))));
            this.ele_bill.BorderColorIdle = System.Drawing.Color.Silver;
            this.ele_bill.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(252)))), ((int)(((byte)(69)))));
            this.ele_bill.BorderThickness = 3;
            this.ele_bill.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ele_bill.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ele_bill.ForeColor = System.Drawing.Color.White;
            this.ele_bill.isPassword = false;
            this.ele_bill.Location = new System.Drawing.Point(658, 202);
            this.ele_bill.Margin = new System.Windows.Forms.Padding(5);
            this.ele_bill.Name = "ele_bill";
            this.ele_bill.Size = new System.Drawing.Size(405, 46);
            this.ele_bill.TabIndex = 89;
            this.ele_bill.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel48
            // 
            this.bunifuCustomLabel48.AutoSize = true;
            this.bunifuCustomLabel48.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel48.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel48.Location = new System.Drawing.Point(123, 167);
            this.bunifuCustomLabel48.Name = "bunifuCustomLabel48";
            this.bunifuCustomLabel48.Size = new System.Drawing.Size(183, 24);
            this.bunifuCustomLabel48.TabIndex = 88;
            this.bunifuCustomLabel48.Text = "The Cook\'s Payment:";
            // 
            // cook_pay
            // 
            this.cook_pay.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(120)))), ((int)(((byte)(33)))));
            this.cook_pay.BorderColorIdle = System.Drawing.Color.Silver;
            this.cook_pay.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(252)))), ((int)(((byte)(69)))));
            this.cook_pay.BorderThickness = 3;
            this.cook_pay.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.cook_pay.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cook_pay.ForeColor = System.Drawing.Color.White;
            this.cook_pay.isPassword = false;
            this.cook_pay.Location = new System.Drawing.Point(124, 199);
            this.cook_pay.Margin = new System.Windows.Forms.Padding(5);
            this.cook_pay.Name = "cook_pay";
            this.cook_pay.Size = new System.Drawing.Size(405, 46);
            this.cook_pay.TabIndex = 86;
            this.cook_pay.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel50
            // 
            this.bunifuCustomLabel50.AutoSize = true;
            this.bunifuCustomLabel50.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel50.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel50.Location = new System.Drawing.Point(120, 75);
            this.bunifuCustomLabel50.Name = "bunifuCustomLabel50";
            this.bunifuCustomLabel50.Size = new System.Drawing.Size(140, 24);
            this.bunifuCustomLabel50.TabIndex = 85;
            this.bunifuCustomLabel50.Text = "Inventory Price:";
            // 
            // inv_price
            // 
            this.inv_price.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(120)))), ((int)(((byte)(33)))));
            this.inv_price.BorderColorIdle = System.Drawing.Color.Silver;
            this.inv_price.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(252)))), ((int)(((byte)(69)))));
            this.inv_price.BorderThickness = 3;
            this.inv_price.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.inv_price.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inv_price.ForeColor = System.Drawing.Color.White;
            this.inv_price.isPassword = false;
            this.inv_price.Location = new System.Drawing.Point(123, 115);
            this.inv_price.Margin = new System.Windows.Forms.Padding(5);
            this.inv_price.Name = "inv_price";
            this.inv_price.Size = new System.Drawing.Size(405, 46);
            this.inv_price.TabIndex = 84;
            this.inv_price.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuFlatButton4
            // 
            this.bunifuFlatButton4.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton4.BorderRadius = 0;
            this.bunifuFlatButton4.ButtonText = "Calculate Total";
            this.bunifuFlatButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton4.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton4.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton4.Iconimage = null;
            this.bunifuFlatButton4.Iconimage_right = null;
            this.bunifuFlatButton4.Iconimage_right_Selected = null;
            this.bunifuFlatButton4.Iconimage_Selected = null;
            this.bunifuFlatButton4.IconMarginLeft = 0;
            this.bunifuFlatButton4.IconMarginRight = 0;
            this.bunifuFlatButton4.IconRightVisible = true;
            this.bunifuFlatButton4.IconRightZoom = 0D;
            this.bunifuFlatButton4.IconVisible = true;
            this.bunifuFlatButton4.IconZoom = 90D;
            this.bunifuFlatButton4.IsTab = false;
            this.bunifuFlatButton4.Location = new System.Drawing.Point(641, 410);
            this.bunifuFlatButton4.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuFlatButton4.Name = "bunifuFlatButton4";
            this.bunifuFlatButton4.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton4.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton4.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton4.selected = false;
            this.bunifuFlatButton4.Size = new System.Drawing.Size(236, 46);
            this.bunifuFlatButton4.TabIndex = 82;
            this.bunifuFlatButton4.Text = "Calculate Total";
            this.bunifuFlatButton4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton4.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton4.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton4.Click += new System.EventHandler(this.bunifuFlatButton4_Click);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(435, 22);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(337, 32);
            this.bunifuCustomLabel1.TabIndex = 57;
            this.bunifuCustomLabel1.Text = "Daily Cost Management";
            // 
            // r_name
            // 
            this.r_name.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(120)))), ((int)(((byte)(33)))));
            this.r_name.BorderColorIdle = System.Drawing.Color.Silver;
            this.r_name.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(252)))), ((int)(((byte)(69)))));
            this.r_name.BorderThickness = 3;
            this.r_name.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.r_name.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r_name.ForeColor = System.Drawing.Color.White;
            this.r_name.isPassword = false;
            this.r_name.Location = new System.Drawing.Point(103, 161);
            this.r_name.Margin = new System.Windows.Forms.Padding(5);
            this.r_name.Name = "r_name";
            this.r_name.Size = new System.Drawing.Size(405, 46);
            this.r_name.TabIndex = 85;
            this.r_name.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // r_cost
            // 
            this.r_cost.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(120)))), ((int)(((byte)(33)))));
            this.r_cost.BorderColorIdle = System.Drawing.Color.Silver;
            this.r_cost.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(252)))), ((int)(((byte)(69)))));
            this.r_cost.BorderThickness = 3;
            this.r_cost.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.r_cost.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r_cost.ForeColor = System.Drawing.Color.White;
            this.r_cost.isPassword = false;
            this.r_cost.Location = new System.Drawing.Point(104, 250);
            this.r_cost.Margin = new System.Windows.Forms.Padding(5);
            this.r_cost.Name = "r_cost";
            this.r_cost.Size = new System.Drawing.Size(405, 46);
            this.r_cost.TabIndex = 86;
            this.r_cost.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // r_note
            // 
            this.r_note.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(120)))), ((int)(((byte)(33)))));
            this.r_note.BorderColorIdle = System.Drawing.Color.Silver;
            this.r_note.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(252)))), ((int)(((byte)(69)))));
            this.r_note.BorderThickness = 3;
            this.r_note.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.r_note.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r_note.ForeColor = System.Drawing.Color.White;
            this.r_note.isPassword = false;
            this.r_note.Location = new System.Drawing.Point(105, 345);
            this.r_note.Margin = new System.Windows.Forms.Padding(5);
            this.r_note.Name = "r_note";
            this.r_note.Size = new System.Drawing.Size(405, 46);
            this.r_note.TabIndex = 87;
            this.r_note.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // test2
            // 
            this.test2.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(120)))), ((int)(((byte)(33)))));
            this.test2.BorderColorIdle = System.Drawing.Color.Silver;
            this.test2.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(252)))), ((int)(((byte)(69)))));
            this.test2.BorderThickness = 3;
            this.test2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.test2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.test2.ForeColor = System.Drawing.Color.White;
            this.test2.isPassword = false;
            this.test2.Location = new System.Drawing.Point(103, 70);
            this.test2.Margin = new System.Windows.Forms.Padding(5);
            this.test2.Name = "test2";
            this.test2.Size = new System.Drawing.Size(405, 46);
            this.test2.TabIndex = 84;
            this.test2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuFlatButton7
            // 
            this.bunifuFlatButton7.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton7.BorderRadius = 0;
            this.bunifuFlatButton7.ButtonText = "Remove Receipe";
            this.bunifuFlatButton7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton7.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton7.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton7.Iconimage = null;
            this.bunifuFlatButton7.Iconimage_right = null;
            this.bunifuFlatButton7.Iconimage_right_Selected = null;
            this.bunifuFlatButton7.Iconimage_Selected = null;
            this.bunifuFlatButton7.IconMarginLeft = 0;
            this.bunifuFlatButton7.IconMarginRight = 0;
            this.bunifuFlatButton7.IconRightVisible = true;
            this.bunifuFlatButton7.IconRightZoom = 0D;
            this.bunifuFlatButton7.IconVisible = true;
            this.bunifuFlatButton7.IconZoom = 90D;
            this.bunifuFlatButton7.IsTab = false;
            this.bunifuFlatButton7.Location = new System.Drawing.Point(324, 439);
            this.bunifuFlatButton7.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuFlatButton7.Name = "bunifuFlatButton7";
            this.bunifuFlatButton7.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton7.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton7.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton7.selected = false;
            this.bunifuFlatButton7.Size = new System.Drawing.Size(230, 46);
            this.bunifuFlatButton7.TabIndex = 88;
            this.bunifuFlatButton7.Text = "Remove Receipe";
            this.bunifuFlatButton7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton7.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton7.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton7.Click += new System.EventHandler(this.bunifuFlatButton7_Click);
            // 
            // bunifuFlatButton8
            // 
            this.bunifuFlatButton8.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton8.BorderRadius = 0;
            this.bunifuFlatButton8.ButtonText = "Show Receipe by ID";
            this.bunifuFlatButton8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton8.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton8.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton8.Iconimage = null;
            this.bunifuFlatButton8.Iconimage_right = null;
            this.bunifuFlatButton8.Iconimage_right_Selected = null;
            this.bunifuFlatButton8.Iconimage_Selected = null;
            this.bunifuFlatButton8.IconMarginLeft = 0;
            this.bunifuFlatButton8.IconMarginRight = 0;
            this.bunifuFlatButton8.IconRightVisible = true;
            this.bunifuFlatButton8.IconRightZoom = 0D;
            this.bunifuFlatButton8.IconVisible = true;
            this.bunifuFlatButton8.IconZoom = 90D;
            this.bunifuFlatButton8.IsTab = false;
            this.bunifuFlatButton8.Location = new System.Drawing.Point(45, 439);
            this.bunifuFlatButton8.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuFlatButton8.Name = "bunifuFlatButton8";
            this.bunifuFlatButton8.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton8.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton8.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton8.selected = false;
            this.bunifuFlatButton8.Size = new System.Drawing.Size(230, 46);
            this.bunifuFlatButton8.TabIndex = 89;
            this.bunifuFlatButton8.Text = "Show Receipe by ID";
            this.bunifuFlatButton8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton8.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton8.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton8.Click += new System.EventHandler(this.bunifuFlatButton8_Click);
            // 
            // supp_view
            // 
            this.supp_view.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.supp_view.Location = new System.Drawing.Point(668, 92);
            this.supp_view.Name = "supp_view";
            this.supp_view.RowHeadersWidth = 51;
            this.supp_view.RowTemplate.Height = 24;
            this.supp_view.Size = new System.Drawing.Size(493, 280);
            this.supp_view.TabIndex = 80;
            // 
            // bunifuSeparator3
            // 
            this.bunifuSeparator3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuSeparator3.LineThickness = 3;
            this.bunifuSeparator3.Location = new System.Drawing.Point(596, 92);
            this.bunifuSeparator3.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuSeparator3.Name = "bunifuSeparator3";
            this.bunifuSeparator3.Size = new System.Drawing.Size(17, 280);
            this.bunifuSeparator3.TabIndex = 84;
            this.bunifuSeparator3.Transparency = 255;
            this.bunifuSeparator3.Vertical = true;
            // 
            // bunifuFlatButton9
            // 
            this.bunifuFlatButton9.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton9.BorderRadius = 0;
            this.bunifuFlatButton9.ButtonText = "Remove Supplier";
            this.bunifuFlatButton9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton9.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton9.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton9.Iconimage = null;
            this.bunifuFlatButton9.Iconimage_right = null;
            this.bunifuFlatButton9.Iconimage_right_Selected = null;
            this.bunifuFlatButton9.Iconimage_Selected = null;
            this.bunifuFlatButton9.IconMarginLeft = 0;
            this.bunifuFlatButton9.IconMarginRight = 0;
            this.bunifuFlatButton9.IconRightVisible = true;
            this.bunifuFlatButton9.IconRightZoom = 0D;
            this.bunifuFlatButton9.IconVisible = true;
            this.bunifuFlatButton9.IconZoom = 90D;
            this.bunifuFlatButton9.IsTab = false;
            this.bunifuFlatButton9.Location = new System.Drawing.Point(668, 420);
            this.bunifuFlatButton9.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuFlatButton9.Name = "bunifuFlatButton9";
            this.bunifuFlatButton9.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton9.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton9.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton9.selected = false;
            this.bunifuFlatButton9.Size = new System.Drawing.Size(230, 46);
            this.bunifuFlatButton9.TabIndex = 85;
            this.bunifuFlatButton9.Text = "Remove Supplier";
            this.bunifuFlatButton9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton9.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton9.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton9.Click += new System.EventHandler(this.bunifuFlatButton9_Click);
            // 
            // bunifuFlatButton12
            // 
            this.bunifuFlatButton12.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton12.BorderRadius = 0;
            this.bunifuFlatButton12.ButtonText = "Check Details";
            this.bunifuFlatButton12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton12.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton12.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton12.Iconimage = null;
            this.bunifuFlatButton12.Iconimage_right = null;
            this.bunifuFlatButton12.Iconimage_right_Selected = null;
            this.bunifuFlatButton12.Iconimage_Selected = null;
            this.bunifuFlatButton12.IconMarginLeft = 0;
            this.bunifuFlatButton12.IconMarginRight = 0;
            this.bunifuFlatButton12.IconRightVisible = true;
            this.bunifuFlatButton12.IconRightZoom = 0D;
            this.bunifuFlatButton12.IconVisible = true;
            this.bunifuFlatButton12.IconZoom = 90D;
            this.bunifuFlatButton12.IsTab = false;
            this.bunifuFlatButton12.Location = new System.Drawing.Point(40, 420);
            this.bunifuFlatButton12.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuFlatButton12.Name = "bunifuFlatButton12";
            this.bunifuFlatButton12.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton12.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton12.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton12.selected = false;
            this.bunifuFlatButton12.Size = new System.Drawing.Size(230, 46);
            this.bunifuFlatButton12.TabIndex = 87;
            this.bunifuFlatButton12.Text = "Check Details";
            this.bunifuFlatButton12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton12.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton12.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton12.Click += new System.EventHandler(this.bunifuFlatButton12_Click);
            // 
            // bunifuFlatButton10
            // 
            this.bunifuFlatButton10.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton10.BorderRadius = 0;
            this.bunifuFlatButton10.ButtonText = "Update Details";
            this.bunifuFlatButton10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton10.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton10.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton10.Iconimage = null;
            this.bunifuFlatButton10.Iconimage_right = null;
            this.bunifuFlatButton10.Iconimage_right_Selected = null;
            this.bunifuFlatButton10.Iconimage_Selected = null;
            this.bunifuFlatButton10.IconMarginLeft = 0;
            this.bunifuFlatButton10.IconMarginRight = 0;
            this.bunifuFlatButton10.IconRightVisible = true;
            this.bunifuFlatButton10.IconRightZoom = 0D;
            this.bunifuFlatButton10.IconVisible = true;
            this.bunifuFlatButton10.IconZoom = 90D;
            this.bunifuFlatButton10.IsTab = false;
            this.bunifuFlatButton10.Location = new System.Drawing.Point(314, 420);
            this.bunifuFlatButton10.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuFlatButton10.Name = "bunifuFlatButton10";
            this.bunifuFlatButton10.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton10.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton10.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton10.selected = false;
            this.bunifuFlatButton10.Size = new System.Drawing.Size(230, 46);
            this.bunifuFlatButton10.TabIndex = 86;
            this.bunifuFlatButton10.Text = "Update Details";
            this.bunifuFlatButton10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton10.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton10.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton10.Click += new System.EventHandler(this.bunifuFlatButton10_Click);
            // 
            // bunifuFlatButton13
            // 
            this.bunifuFlatButton13.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton13.BorderRadius = 0;
            this.bunifuFlatButton13.ButtonText = "Save";
            this.bunifuFlatButton13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton13.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton13.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton13.Iconimage = null;
            this.bunifuFlatButton13.Iconimage_right = null;
            this.bunifuFlatButton13.Iconimage_right_Selected = null;
            this.bunifuFlatButton13.Iconimage_Selected = null;
            this.bunifuFlatButton13.IconMarginLeft = 0;
            this.bunifuFlatButton13.IconMarginRight = 0;
            this.bunifuFlatButton13.IconRightVisible = true;
            this.bunifuFlatButton13.IconRightZoom = 0D;
            this.bunifuFlatButton13.IconVisible = true;
            this.bunifuFlatButton13.IconZoom = 90D;
            this.bunifuFlatButton13.IsTab = false;
            this.bunifuFlatButton13.Location = new System.Drawing.Point(908, 410);
            this.bunifuFlatButton13.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuFlatButton13.Name = "bunifuFlatButton13";
            this.bunifuFlatButton13.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton13.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton13.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton13.selected = false;
            this.bunifuFlatButton13.Size = new System.Drawing.Size(236, 46);
            this.bunifuFlatButton13.TabIndex = 101;
            this.bunifuFlatButton13.Text = "Save";
            this.bunifuFlatButton13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton13.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton13.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton13.Click += new System.EventHandler(this.bunifuFlatButton13_Click);
            // 
            // datepick_cost
            // 
            this.datepick_cost.BackColor = System.Drawing.Color.SeaGreen;
            this.datepick_cost.BorderRadius = 0;
            this.datepick_cost.ForeColor = System.Drawing.Color.White;
            this.datepick_cost.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.datepick_cost.FormatCustom = null;
            this.datepick_cost.Location = new System.Drawing.Point(120, 290);
            this.datepick_cost.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.datepick_cost.Name = "datepick_cost";
            this.datepick_cost.Size = new System.Drawing.Size(402, 46);
            this.datepick_cost.TabIndex = 102;
            this.datepick_cost.Value = new System.DateTime(2023, 6, 16, 1, 5, 3, 397);
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel4.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(120, 262);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(59, 24);
            this.bunifuCustomLabel4.TabIndex = 103;
            this.bunifuCustomLabel4.Text = "Date :\r\n";
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Calibri", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel5.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(654, 298);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(102, 41);
            this.bunifuCustomLabel5.TabIndex = 104;
            this.bunifuCustomLabel5.Text = "Total :";
            // 
            // tot
            // 
            this.tot.AutoSize = true;
            this.tot.Font = new System.Drawing.Font("Calibri", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tot.ForeColor = System.Drawing.Color.Silver;
            this.tot.Location = new System.Drawing.Point(754, 298);
            this.tot.Name = "tot";
            this.tot.Size = new System.Drawing.Size(135, 41);
            this.tot.TabIndex = 105;
            this.tot.Text = ".............";
            // 
            // panelCostCalculate
            // 
            this.panelCostCalculate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(65)))), ((int)(((byte)(94)))));
            this.panelCostCalculate.Controls.Add(this.invView);
            this.panelCostCalculate.Controls.Add(this.bunifuCustomLabel13);
            this.panelCostCalculate.Controls.Add(this.bunifuFlatButton14);
            this.panelCostCalculate.Controls.Add(this.suppView);
            this.panelCostCalculate.Controls.Add(this.bunifuCustomLabel8);
            this.panelCostCalculate.Controls.Add(this.bunifuCustomLabel27);
            this.panelCostCalculate.Location = new System.Drawing.Point(148, 224);
            this.panelCostCalculate.Margin = new System.Windows.Forms.Padding(4);
            this.panelCostCalculate.Name = "panelCostCalculate";
            this.panelCostCalculate.Size = new System.Drawing.Size(1207, 508);
            this.panelCostCalculate.TabIndex = 82;
            // 
            // bunifuFlatButton14
            // 
            this.bunifuFlatButton14.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton14.BorderRadius = 0;
            this.bunifuFlatButton14.ButtonText = "Check Details";
            this.bunifuFlatButton14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton14.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton14.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton14.Iconimage = null;
            this.bunifuFlatButton14.Iconimage_right = null;
            this.bunifuFlatButton14.Iconimage_right_Selected = null;
            this.bunifuFlatButton14.Iconimage_Selected = null;
            this.bunifuFlatButton14.IconMarginLeft = 0;
            this.bunifuFlatButton14.IconMarginRight = 0;
            this.bunifuFlatButton14.IconRightVisible = true;
            this.bunifuFlatButton14.IconRightZoom = 0D;
            this.bunifuFlatButton14.IconVisible = true;
            this.bunifuFlatButton14.IconZoom = 90D;
            this.bunifuFlatButton14.IsTab = false;
            this.bunifuFlatButton14.Location = new System.Drawing.Point(931, 439);
            this.bunifuFlatButton14.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuFlatButton14.Name = "bunifuFlatButton14";
            this.bunifuFlatButton14.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton14.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton14.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton14.selected = false;
            this.bunifuFlatButton14.Size = new System.Drawing.Size(230, 46);
            this.bunifuFlatButton14.TabIndex = 87;
            this.bunifuFlatButton14.Text = "Check Details";
            this.bunifuFlatButton14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton14.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton14.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton14.Click += new System.EventHandler(this.bunifuFlatButton14_Click);
            // 
            // suppView
            // 
            this.suppView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.suppView.Location = new System.Drawing.Point(40, 75);
            this.suppView.Name = "suppView";
            this.suppView.RowHeadersWidth = 51;
            this.suppView.RowTemplate.Height = 24;
            this.suppView.Size = new System.Drawing.Size(1116, 163);
            this.suppView.TabIndex = 80;
            // 
            // bunifuCustomLabel8
            // 
            this.bunifuCustomLabel8.AutoSize = true;
            this.bunifuCustomLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel8.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuCustomLabel8.Location = new System.Drawing.Point(512, 14);
            this.bunifuCustomLabel8.Name = "bunifuCustomLabel8";
            this.bunifuCustomLabel8.Size = new System.Drawing.Size(215, 32);
            this.bunifuCustomLabel8.TabIndex = 44;
            this.bunifuCustomLabel8.Text = "Check All Data";
            // 
            // bunifuCustomLabel27
            // 
            this.bunifuCustomLabel27.AutoSize = true;
            this.bunifuCustomLabel27.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel27.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel27.Location = new System.Drawing.Point(41, 46);
            this.bunifuCustomLabel27.Name = "bunifuCustomLabel27";
            this.bunifuCustomLabel27.Size = new System.Drawing.Size(105, 30);
            this.bunifuCustomLabel27.TabIndex = 33;
            this.bunifuCustomLabel27.Text = "Supplier:\r\n";
            // 
            // invView
            // 
            this.invView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.invView.Location = new System.Drawing.Point(45, 281);
            this.invView.Name = "invView";
            this.invView.RowHeadersWidth = 51;
            this.invView.RowTemplate.Height = 24;
            this.invView.Size = new System.Drawing.Size(1116, 150);
            this.invView.TabIndex = 90;
            // 
            // bunifuCustomLabel13
            // 
            this.bunifuCustomLabel13.AutoSize = true;
            this.bunifuCustomLabel13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel13.ForeColor = System.Drawing.Color.Silver;
            this.bunifuCustomLabel13.Location = new System.Drawing.Point(41, 254);
            this.bunifuCustomLabel13.Name = "bunifuCustomLabel13";
            this.bunifuCustomLabel13.Size = new System.Drawing.Size(119, 30);
            this.bunifuCustomLabel13.TabIndex = 89;
            this.bunifuCustomLabel13.Text = "Inventory:\r\n";
            // 
            // bunifuImageButton4
            // 
            this.bunifuImageButton4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton4.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton4.Image")));
            this.bunifuImageButton4.ImageActive = null;
            this.bunifuImageButton4.InitialImage = null;
            this.bunifuImageButton4.Location = new System.Drawing.Point(31, 503);
            this.bunifuImageButton4.Name = "bunifuImageButton4";
            this.bunifuImageButton4.Size = new System.Drawing.Size(70, 60);
            this.bunifuImageButton4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton4.TabIndex = 83;
            this.bunifuImageButton4.TabStop = false;
            this.bunifuImageButton4.Zoom = 10;
            this.bunifuImageButton4.Click += new System.EventHandler(this.bunifuImageButton4_Click);
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(49)))), ((int)(((byte)(60)))));
            this.ClientSize = new System.Drawing.Size(1409, 800);
            this.Controls.Add(this.bunifuImageButton4);
            this.Controls.Add(this.panelCostCalculate);
            this.Controls.Add(this.panelAddWasteMangement);
            this.Controls.Add(this.panelAddSupplier);
            this.Controls.Add(this.panelAddReceipe);
            this.Controls.Add(this.panelAddProduct);
            this.Controls.Add(this.bunifuImageButton5);
            this.Controls.Add(this.bunifuCustomLabel35);
            this.Controls.Add(this.lbl_id);
            this.Controls.Add(this.bunifuImageButton1);
            this.Controls.Add(this.Btn_cost);
            this.Controls.Add(this.Btn_supplier);
            this.Controls.Add(this.Btn_receipe);
            this.Controls.Add(this.line1);
            this.Controls.Add(this.Btn_inventry);
            this.Controls.Add(this.Btn_waste_manage);
            this.Controls.Add(this.bunifuImageButton2);
            this.Controls.Add(this.bunifuCustomLabel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Dashboard";
            this.RightToLeftLayout = true;
            this.Text = "Dashboard";
            this.Load += new System.EventHandler(this.Dashboard_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton5)).EndInit();
            this.panelAddProduct.ResumeLayout(false);
            this.panelAddProduct.PerformLayout();
            this.panelAddReceipe.ResumeLayout(false);
            this.panelAddReceipe.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rece_view)).EndInit();
            this.panelAddSupplier.ResumeLayout(false);
            this.panelAddSupplier.PerformLayout();
            this.panelAddWasteMangement.ResumeLayout(false);
            this.panelAddWasteMangement.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.supp_view)).EndInit();
            this.panelCostCalculate.ResumeLayout(false);
            this.panelCostCalculate.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.suppView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuFlatButton Btn_cost;
        private Bunifu.Framework.UI.BunifuFlatButton Btn_supplier;
        private Bunifu.Framework.UI.BunifuFlatButton Btn_receipe;
        private Bunifu.Framework.UI.BunifuSeparator line1;
        private Bunifu.Framework.UI.BunifuFlatButton Btn_inventry;
        private Bunifu.Framework.UI.BunifuFlatButton Btn_waste_manage;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton5;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel35;
        private Bunifu.Framework.UI.BunifuCustomLabel lbl_id;
        private System.Windows.Forms.Panel panelAddProduct;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel22;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel19;
        private Bunifu.Framework.UI.BunifuDatepicker exp_date;
        private Bunifu.Framework.UI.BunifuMetroTextbox p_price;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel18;
        private Bunifu.Framework.UI.BunifuMetroTextbox p_qua;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel15;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel11;
        private Bunifu.Framework.UI.BunifuMetroTextbox p_name;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel14;
        private Bunifu.Framework.UI.BunifuMetroTextbox pid;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton11;
        private System.Windows.Forms.Panel panelAddReceipe;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel7;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel9;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel10;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
        private System.Windows.Forms.Panel panelAddSupplier;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel20;
        private Bunifu.Framework.UI.BunifuMetroTextbox supp_items;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel25;
        private Bunifu.Framework.UI.BunifuMetroTextbox supp_phone;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel26;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel28;
        private Bunifu.Framework.UI.BunifuMetroTextbox supp_name;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel29;
        private Bunifu.Framework.UI.BunifuMetroTextbox supp_id;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton2;
        private System.Windows.Forms.Panel panelAddWasteMangement;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel42;
        private Bunifu.Framework.UI.BunifuMetroTextbox supp_pay;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel45;
        private Bunifu.Framework.UI.BunifuMetroTextbox ele_bill;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel48;
        private Bunifu.Framework.UI.BunifuMetroTextbox cook_pay;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel50;
        private Bunifu.Framework.UI.BunifuMetroTextbox inv_price;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton4;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        private Bunifu.Framework.UI.BunifuMetroTextbox update_pqua;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel12;
        private Bunifu.Framework.UI.BunifuMetroTextbox update_pid;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton5;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel17;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton6;
        private System.Windows.Forms.DataGridView rece_view;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator2;
        private Bunifu.Framework.UI.BunifuMetroTextbox r_note;
        private Bunifu.Framework.UI.BunifuMetroTextbox r_cost;
        private Bunifu.Framework.UI.BunifuMetroTextbox r_name;
        private Bunifu.Framework.UI.BunifuMetroTextbox test2;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton7;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton8;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton12;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton9;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator3;
        private System.Windows.Forms.DataGridView supp_view;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton10;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton13;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.Framework.UI.BunifuDatepicker datepick_cost;
        private Bunifu.Framework.UI.BunifuCustomLabel tot;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private System.Windows.Forms.Panel panelCostCalculate;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton14;
        private System.Windows.Forms.DataGridView suppView;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel8;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel27;
        private System.Windows.Forms.DataGridView invView;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel13;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton4;
    }
}